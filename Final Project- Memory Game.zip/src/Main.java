// Author: Yanxi Chen
//ChatGPT work included
// Date: 5/30/2024
// CSA Final Project


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Main implements ActionListener {
    JFrame frame = new JFrame("Memory Card Game");//Creat frame with title

    //components of the window
    JButton start = new JButton("Start");
    JButton exit = new JButton("Exit");
    JButton backMain = new JButton("Main Menu");
    JButton btn[] = new JButton[20];

    JPanel startPanel = new JPanel();
    JPanel endPanel = new JPanel();
    JPanel field = new JPanel();

    //use to arrange buttons
    JPanel sort = new JPanel();
    JPanel sort2 = new JPanel();
    JPanel sort3 = new JPanel();
    JPanel sort4 = new JPanel();

    JLabel difficulty = new JLabel("Enter difficulty level from 1 to 10");
    JTextField text = new JTextField(10);//collect user input of level of difficulty

    String[] board;//track status of each button
    Random randomGenerator = new Random();
    Boolean shown = true;

    ImageIcon[] images = new ImageIcon[10];

    int level = 0;
    int mistake = 0;

    //Below from ChatGPT for actionPerformed method
    private boolean purgatory = false;
    int temp = 30;
    int temp2 = 30;

    public Main(){
        loadImages();

        frame.setSize(1000,600);//size of window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);//center the window
        frame.setLayout(new BorderLayout());
        startPanel.setLayout(new FlowLayout());
        sort.setLayout(new FlowLayout());
        sort2.setLayout(new FlowLayout());
        sort3.setLayout(new FlowLayout());
        sort4.setLayout(new FlowLayout());

        //Changing the size
        Font largerFont = new Font("Serif", Font.PLAIN, 20);
        difficulty.setFont(largerFont);
        text.setFont(largerFont);
        start.setFont(largerFont);
        exit.setFont(largerFont);

        Dimension buttonSize = new Dimension(300, 60);
        start.setPreferredSize(buttonSize);
        exit.setPreferredSize(buttonSize);


        //Add components to small panels
        sort.add(difficulty);
        sort.add(text);
        sort3.add(sort4, BorderLayout.CENTER);
        sort2.add(start);
        sort2.add(exit);


        //Arrange all the small panel on big panel
        startPanel.add(sort,BorderLayout.NORTH);
        startPanel.add(sort3, BorderLayout.CENTER);
        startPanel.add(sort2,BorderLayout.SOUTH);

        start.addActionListener(this);
        exit.addActionListener(this);
        backMain.addActionListener(this);



        frame.add(startPanel,BorderLayout.CENTER);
        frame.setVisible(true);//show
    }


    private void loadImages(){
        images[0] = new ImageIcon("src/1.png");
        images[1] = new ImageIcon("src/2.png");
        images[2] = new ImageIcon("src/3.png");
        images[3] = new ImageIcon("src/4.png");
        images[4] = new ImageIcon("src/5.png");
        images[5] = new ImageIcon("src/6.png");
        images[6] = new ImageIcon("src/7.png");
        images[7] = new ImageIcon("src/8.png");
        images[8] = new ImageIcon("src/9.png");
        images[9] = new ImageIcon("src/10.png");

    }

    public void gameSetUp(int level){
        this.level = level;
        clearMenu();//clear initial menu

        board = new String[2*level]; // use to store state of buttons

        for (int i = 0; i < (level * 2); i++) {
            btn[i] = new JButton("");
            btn[i].setPreferredSize(new Dimension(100, 100)); // Set the size of each button
            btn[i].setBackground(new Color(220, 220, 220));
            btn[i].addActionListener(this); // Add action listener to handle button clicks
            btn[i].setEnabled(true);
            field.add(btn[i]); // Add each button to the game field
        }


        for (int i = 0; i < level; i++) {
            for (int z = 0; z < 2; z++) {
                while (true) {
                    int y = randomGenerator.nextInt(level * 2);
                    if (board[y] == null) {
                        btn[y].setIcon(images[i]);
                        board[y] = Integer.toString(i);
                        break;
                    }
                }
            }
        }
        createGameBoard();

    }


    //idea from ChatGPT
    public void createGameBoard(){
        field.setLayout(new GridLayout(4,5,2,2));
        startPanel.add(field, BorderLayout.CENTER); // Add the field panel to the center of the start_screen panel
        startPanel.revalidate(); // Refresh the start_screen panel to reflect the changes
    }

    public void clearMenu(){
        //clear small panels
        startPanel.remove(sort);
        startPanel.remove(sort2);
        startPanel.remove(sort3);

        startPanel.revalidate(); // Refresh the start_screen panel to reflect the changes
        startPanel.repaint(); // Repaint the start_screen panel to update the UI
    }

    //helped with ChatGPT
    public void actionPerformed(ActionEvent x){
        Object source = x.getSource();
        if (purgatory) {
            switchSpot(temp2);
            switchSpot(temp);
            mistake++;
            temp = (level * 2);
            temp2 = 30;
            purgatory = false;
        }
        if (source == start) {
            try {
                level = Integer.parseInt(text.getText());
            } catch (Exception e) {
                level = 1;
            }
            gameSetUp(level);
        }
        if (source == exit) {
            System.exit(0);
        }
        if (source == backMain) {
            frame.dispose();
            goToMainScreen();
        }

        for (int i = 0; i < (level * 2); i++) {
            if (source == btn[i]) {
                if (shown) {
                    hideField(level);
                } else {
                    switchSpot(i);
                    if (temp >= (level * 2)) {
                        temp = i;
                    } else {
                        if (!board[temp].equals(board[i]) || temp == i) {
                            temp2 = i;
                            purgatory = true;
                        } else {
                            board[i] = "done";
                            board[temp] = "done";
                            checkWin();
                            temp = (level * 2);
                        }
                    }
                }
            }
        }
    }

    public void hideField(int x) {
        for (int i = 0; i < (x * 2); i++) {
            btn[i].setIcon(null);
        }
        shown = false;
    }


    //switch the icon of button between hidden and visible
    public void switchSpot(int i) {
        if (!"done".equals(board[i])) { // Check if the button is not already marked as done
            if (btn[i].getIcon() == null) {
                btn[i].setIcon(images[Integer.parseInt(board[i])]); // Show the icon
            } else {
                btn[i].setIcon(null); // Hide the icon
            }
        }
    }



    public void winner() {
        startPanel.remove(field);
        startPanel.add(endPanel, BorderLayout.CENTER);
        endPanel.add(new TextField("You Win"), BorderLayout.NORTH);
        endPanel.add(new TextField("Mistake: " + mistake), BorderLayout.SOUTH);
        endPanel.add(backMain);
        backMain.setEnabled(true);//Show back main button
        backMain.addActionListener(this);
    }


    public boolean checkWin() {
        for (int i = 0; i < (level * 2); i++) {
            if (!"done".equals(board[i])) return false;
        }
        winner();
        return true;
    }

    public void goToMainScreen() {
        new Main();
    }



    public static void main(String[] args) {
        new Main();//run
    }
}
